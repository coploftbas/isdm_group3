class DocumentVersion < ActiveRecord::Base
end
