class Prerequisite < ActiveRecord::Base
end
