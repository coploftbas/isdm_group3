class Document < ActiveRecord::Base
end
