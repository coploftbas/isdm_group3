class ProjectUserRole < ActiveRecord::Base
end
