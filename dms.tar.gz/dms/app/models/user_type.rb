class UserType < ActiveRecord::Base
end
