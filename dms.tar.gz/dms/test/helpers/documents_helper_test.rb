require 'test_helper'

class DocumentsHelperTest < ActionView::TestCase
end
