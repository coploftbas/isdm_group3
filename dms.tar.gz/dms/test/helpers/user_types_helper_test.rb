require 'test_helper'

class UserTypesHelperTest < ActionView::TestCase
end
