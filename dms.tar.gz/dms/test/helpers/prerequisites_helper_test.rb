require 'test_helper'

class PrerequisitesHelperTest < ActionView::TestCase
end
