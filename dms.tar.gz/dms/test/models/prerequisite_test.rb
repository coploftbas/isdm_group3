require 'test_helper'

class PrerequisiteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
