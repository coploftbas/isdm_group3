require 'test_helper'

class ProjectUserRoleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
